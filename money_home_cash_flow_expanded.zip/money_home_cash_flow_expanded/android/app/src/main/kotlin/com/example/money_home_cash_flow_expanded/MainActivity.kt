package com.example.money_home_cash_flow_expanded

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
