
import '../../domain/entities/money_bar_graph.dart';
import '../../domain/entities/money_bar_graph_data_point.dart';

class MoneyBarGraphModel extends MoneyBarGraph {
  MoneyBarGraphModel({
    required String heading,
    required String headingTextColor,
    required String amount,
    required String ctaText,
    required String ctaBackground,
    required List<MoneyBarGraphDataPoint> dataPoints,
  }) : super(
    heading: heading,
    headingTextColor: headingTextColor,
    amount: amount,
    ctaText: ctaText,
    ctaBackground: ctaBackground,
    dataPoints: dataPoints,
  );

  factory MoneyBarGraphModel.fromJson(Map<String, dynamic> json) {
    final dataPointsJson = json['dataPoints'] as List<dynamic>;
    List<MoneyBarGraphDataPoint> dataPoints = dataPointsJson.map((e) {
      final month = e['month'] as String;
      final value = (e['value'] as num).toDouble();
      return MoneyBarGraphDataPoint(
        xLabel: month,
        xSubLabel: month,
        yValue: value,
        yLabel: value.toString(), // या आप इसे किसी फॉर्मैट में बदल सकते हैं
      );
    }).toList();

    return MoneyBarGraphModel(
      heading: json['heading'] as String,
      headingTextColor: json['headingTextColor'] as String,
      amount: json['amount'] as String,
      ctaText: json['ctaText'] as String,
      ctaBackground: json['ctaBackground'] as String,
      dataPoints: dataPoints,
    );
  }
}
