
import 'dart:convert';

import 'package:http/http.dart' as http;

import '../../domain/entities/money_bar_graph.dart';
import '../../domain/repositories/money_bar_graph_repository.dart';
import '../models/money_bar_graph_model.dart';

class MoneyBarGraphRepositoryImpl implements MoneyBarGraphRepository {
  final String endpoint;

  MoneyBarGraphRepositoryImpl({required this.endpoint});

  @override
  Future<MoneyBarGraph> getMoneyBarGraphData() async {
    final response = await http.get(Uri.parse(endpoint));
    if (response.statusCode == 200) {
      final jsonData = json.decode(response.body);
      return MoneyBarGraphModel.fromJson(jsonData);
    } else {
      throw Exception('Failed to load Money Bar Graph data');
    }
  }
}
