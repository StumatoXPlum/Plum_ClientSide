
import '../entities/money_bar_graph.dart';

abstract class MoneyBarGraphRepository {
  Future<MoneyBarGraph> getMoneyBarGraphData();
}
