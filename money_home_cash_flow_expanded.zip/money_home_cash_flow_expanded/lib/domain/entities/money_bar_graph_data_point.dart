
class MoneyBarGraphDataPoint {
  final String xLabel;
  final String xSubLabel;
  final double yValue;
  final String yLabel;

  MoneyBarGraphDataPoint({
    required this.xLabel,
    required this.xSubLabel,
    required this.yValue,
    required this.yLabel,
  });
}
