
import 'money_bar_graph_data_point.dart';

class MoneyBarGraph {
  final String heading;
  final String headingTextColor;
  final String amount;
  final String ctaText;
  final String ctaBackground;
  final List<MoneyBarGraphDataPoint> dataPoints;

  MoneyBarGraph({
    required this.heading,
    required this.headingTextColor,
    required this.amount,
    required this.ctaText,
    required this.ctaBackground,
    required this.dataPoints,
  });
}
