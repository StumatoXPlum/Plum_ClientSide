
import '../entities/money_bar_graph.dart';
import '../repositories/money_bar_graph_repository.dart';

class GetMoneyBarGraphData {
  final MoneyBarGraphRepository repository;

  GetMoneyBarGraphData(this.repository);

  Future<MoneyBarGraph> call() async {
    return await repository.getMoneyBarGraphData();
  }
}
