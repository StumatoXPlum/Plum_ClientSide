// lib/main.dart
import 'package:flutter/material.dart';
import 'package:money_home_cash_flow_expanded/presentation/views/bar_graph_screen.dart';
import 'data/repositories/money_bar_graph_repository_impl.dart';
import 'domain/usecases/get_money_bar_graph_data.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  final String endpoint = "https://www.jsonkeeper.com/b/1EJB";

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Money Bar Graph',
      home: Scaffold(
        body: FutureBuilder(
          future: _fetchBarData(),
          builder: (context, snapshot) {
            if (snapshot.hasData) {
              final barData = snapshot.data as List<BarData>;
              return BarGraphScreen(
                data: barData,
                width: MediaQuery.of(context).size.width,
                height: 300,
                onBarTap: (index) {
                  // Handle bar tap if needed
                  print("Bar tapped: $index");
                },
              );
            } else if (snapshot.hasError) {
              return Center(child: Text('Error: ${snapshot.error}'));
            }
            return const Center(child: CircularProgressIndicator());
          },
        ),
      ),
    );
  }

  Future<List<BarData>> _fetchBarData() async {
    final repository =
    MoneyBarGraphRepositoryImpl(endpoint: endpoint);
    final useCase = GetMoneyBarGraphData(repository);
    final moneyBarGraph = await useCase();

    final barData = moneyBarGraph.dataPoints
        .map((dp) => BarData(
      month: dp.xLabel,
      value: dp.yValue,
    ))
        .toList();
    return barData;
  }
}
