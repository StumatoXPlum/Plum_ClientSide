
import '../../domain/entities/money_bar_graph_data_point.dart';
import '../templates/bar_graph_template.dart';

abstract class BaseMoneyVm {

}

class MoneyBarGraphVm implements BaseMoneyVm {
  final String? categoryLabel;
  final List<MoneyBarGraphDataPoint>? dataPoints;
  final BarGraphDecoration? decoration;


  final int selectedBarIndex;
  final double maxYAxisValue;
  final double averageValue;
  final String? averageLabel;
  final int numberOfBars;

  MoneyBarGraphVm({
    this.categoryLabel,
    this.dataPoints,
    this.decoration,
    this.selectedBarIndex = 0,
    this.maxYAxisValue = 80,
    this.averageValue = 0,
    this.averageLabel,
    this.numberOfBars = 0,
  });
}
