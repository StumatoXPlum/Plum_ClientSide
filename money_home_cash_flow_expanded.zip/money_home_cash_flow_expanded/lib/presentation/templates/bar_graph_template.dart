
import '../../domain/entities/money_bar_graph_data_point.dart';

class BarGraphDecoration {

}

class BarGraphTemplate {
  final String? categoryLabel;
  final List<MoneyBarGraphDataPoint>? dataPoints;
  final BarGraphDecoration? decoration;

  BarGraphTemplate({
    this.categoryLabel,
    this.dataPoints,
    this.decoration,
  });
}
