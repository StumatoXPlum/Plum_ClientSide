
import '../templates/bar_graph_template.dart';
import '../viewmodels/money_bar_graph_vm.dart';

extension BarGraphTemplateExtension on BarGraphTemplate {
  MoneyBarGraphVm toMoneyBarGraphVm() {
    return MoneyBarGraphVm(
      categoryLabel: categoryLabel,
      dataPoints: dataPoints,
      decoration: decoration,
      // Additional computed properties:
      selectedBarIndex: 0,
      maxYAxisValue: dataPoints != null && dataPoints!.isNotEmpty
          ? dataPoints!.map((e) => e.yValue).reduce((a, b) => a > b ? a : b)
          : 80,
      averageValue: dataPoints != null && dataPoints!.isNotEmpty
          ? dataPoints!.map((e) => e.yValue).reduce((a, b) => a + b) / dataPoints!.length
          : 0,
      averageLabel: 'Avg',
      numberOfBars: dataPoints?.length ?? 0,
    );
  }
}
